<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
    <title>What Are The Odds - File Server</title>
</head>
<body>
<h1>Uploaded Images</h1>
<?php
$scan = scandir('uploads');
foreach($scan as $file)
{
    if (!is_dir($file))
    {
        echo '<h3>'.$file.'</h3>';
        echo '<img src="uploads/'.$file.'" style="width: 400px;"/><br />';
    }
}
?>
</body>
</html>